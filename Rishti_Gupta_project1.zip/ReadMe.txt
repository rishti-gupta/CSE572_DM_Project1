Read Me File for Data Mining Project-1

The project is compatible with Python-3.
Command to run the code.py file : python code.py (where python-3 is linked to the system variable)

Install the following packages/python libraries that are used in the project:
1. pandas
2. numpy
3. matplotlib
4. warnings
5. scipy
6. sklearn

The project of the format:
First, all the features are extracted and graphs are plotted corresponding to the features. Then the feature matrix is created and fed into the PCA. Finally, all the results and values of the features are printed at the end of the project.

The code has all the comments which makes it quite explanatory. 